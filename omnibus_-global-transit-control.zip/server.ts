import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Mock API for Bus Data
  app.get("/api/buses", (req, res) => {
    const buses = Array.from({ length: 20 }).map((_, i) => ({
      id: `BUS-${100 + i}`,
      route: ["Downtown", "Airport", "University", "Suburbs"][i % 4],
      status: ["On Time", "Delayed", "Maintenance", "On Time"][i % 4],
      passengers: Math.floor(Math.random() * 50),
      location: {
        lat: 40.7128 + (Math.random() - 0.5) * 0.1,
        lng: -74.0060 + (Math.random() - 0.5) * 0.1,
      },
      lastUpdated: new Date().toISOString(),
    }));
    res.json(buses);
  });

  // Mock API for "Microservices" Health
  app.get("/api/services/health", (req, res) => {
    const services = [
      { id: "svc-auth-01", name: "Auth Validator", status: "healthy", latency: "12ms" },
      { id: "svc-gps-99", name: "GPS Polyline Encoder", status: "healthy", latency: "45ms" },
      { id: "svc-fare-402", name: "Dynamic Fare Calculator", status: "degraded", latency: "890ms" },
      { id: "svc-seat-12", name: "Seat Availability Cache", status: "healthy", latency: "5ms" },
      { id: "svc-ticket-88", name: "QR Code Generator (Rust)", status: "healthy", latency: "2ms" },
    ];
    res.json(services);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
