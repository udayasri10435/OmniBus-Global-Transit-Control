import React, { useState, useEffect } from 'react';
import { 
  Bus, 
  Activity, 
  Map as MapIcon, 
  Settings, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Users, 
  Search,
  LayoutDashboard,
  Server,
  Navigation,
  ChevronRight,
  RefreshCw
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// --- Types ---
interface BusData {
  id: string;
  route: string;
  status: 'On Time' | 'Delayed' | 'Maintenance';
  passengers: number;
  location: { lat: number; lng: number };
  lastUpdated: string;
}

interface ServiceHealth {
  id: string;
  name: string;
  status: 'healthy' | 'degraded' | 'down';
  latency: string;
}

// --- Mock Data ---
const PERFORMANCE_DATA = [
  { time: '08:00', passengers: 420, efficiency: 88 },
  { time: '09:00', passengers: 850, efficiency: 72 },
  { time: '10:00', passengers: 630, efficiency: 85 },
  { time: '11:00', passengers: 510, efficiency: 91 },
  { time: '12:00', passengers: 720, efficiency: 78 },
  { time: '13:00', passengers: 680, efficiency: 82 },
  { time: '14:00', passengers: 590, efficiency: 89 },
];

export default function App() {
  const [buses, setBuses] = useState<BusData[]>([]);
  const [services, setServices] = useState<ServiceHealth[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'fleet' | 'services' | 'analytics'>('fleet');
  const [searchQuery, setSearchQuery] = useState('');
  const [events, setEvents] = useState<{ id: string; msg: string; time: string; type: string }[]>([]);

  useEffect(() => {
    const eventInterval = setInterval(() => {
      const newEvent = {
        id: Math.random().toString(36).substr(2, 9),
        msg: [
          "TICKET_VALIDATED: BUS-102",
          "GPS_PING: BUS-115",
          "FARE_CALCULATED: $2.50",
          "SERVICE_MESH_RETRY: svc-gps-99",
          "KAFKA_PRODUCER_ACK: topic-telemetry",
          "DRIVER_CHECK_IN: DRV-902",
          "MAINTENANCE_ALERT: BUS-108"
        ][Math.floor(Math.random() * 7)],
        time: new Date().toLocaleTimeString(),
        type: ["info", "success", "warning", "error"][Math.floor(Math.random() * 4)]
      };
      setEvents(prev => [newEvent, ...prev].slice(0, 10));
    }, 2000);

    return () => clearInterval(eventInterval);
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [busRes, svcRes] = await Promise.all([
          fetch('/api/buses'),
          fetch('/api/services/health')
        ]);
        const busData = await busRes.json();
        const svcData = await svcRes.json();
        setBuses(busData);
        setServices(svcData);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const filteredBuses = buses.filter(b => 
    b.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
    b.route.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* --- Sidebar --- */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 border-r border-[#141414] bg-[#E4E3E0] z-50 hidden md:flex flex-col">
        <div className="p-6 border-bottom border-[#141414]">
          <div className="flex items-center gap-2 mb-1">
            <Bus className="w-6 h-6" />
            <h1 className="font-serif italic text-xl font-bold tracking-tight">OmniBus</h1>
          </div>
          <p className="text-[10px] uppercase tracking-widest opacity-50 font-mono">Global Transit Control v4.2</p>
        </div>

        <nav className="flex-1 px-4 py-8 space-y-2">
          <NavItem 
            icon={<LayoutDashboard className="w-4 h-4" />} 
            label="Fleet Overview" 
            active={activeTab === 'fleet'} 
            onClick={() => setActiveTab('fleet')}
          />
          <NavItem 
            icon={<Server className="w-4 h-4" />} 
            label="Microservices" 
            active={activeTab === 'services'} 
            onClick={() => setActiveTab('services')}
            badge="1,000+"
          />
          <NavItem 
            icon={<Activity className="w-4 h-4" />} 
            label="Analytics" 
            active={activeTab === 'analytics'} 
            onClick={() => setActiveTab('analytics')}
          />
          <div className="pt-8 opacity-30">
            <p className="px-4 text-[10px] uppercase font-mono mb-4">Operations</p>
            <NavItem icon={<Navigation className="w-4 h-4" />} label="Route Planner" />
            <NavItem icon={<Clock className="w-4 h-4" />} label="Schedules" />
            <NavItem icon={<Settings className="w-4 h-4" />} label="System Config" />
          </div>
        </nav>

        <div className="p-6 border-t border-[#141414] bg-[#141414] text-[#E4E3E0]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#E4E3E0] flex items-center justify-center text-[#141414] font-bold text-xs">
              AD
            </div>
            <div>
              <p className="text-xs font-bold">Admin Console</p>
              <p className="text-[10px] opacity-50 font-mono">ID: 882-XQ-9</p>
            </div>
          </div>
        </div>
      </aside>

      {/* --- Main Content --- */}
      <main className="md:ml-64 p-8">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
          <div>
            <h2 className="text-4xl font-serif italic mb-2">
              {activeTab === 'fleet' && "Active Fleet Management"}
              {activeTab === 'services' && "Polyglot Service Mesh"}
              {activeTab === 'analytics' && "Operational Intelligence"}
            </h2>
            <div className="flex items-center gap-4 text-[11px] font-mono uppercase tracking-wider opacity-60">
              <span className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-green-600 animate-pulse" />
                System Live
              </span>
              <span>•</span>
              <span>Region: US-EAST-1</span>
              <span>•</span>
              <span>{new Date().toLocaleTimeString()}</span>
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 opacity-40" />
            <input 
              type="text" 
              placeholder="SEARCH BUS ID / ROUTE..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent border border-[#141414] pl-10 pr-4 py-2 text-xs font-mono focus:outline-none focus:bg-[#141414] focus:text-[#E4E3E0] transition-colors w-full md:w-64"
            />
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'fleet' && (
            <motion.div 
              key="fleet"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-px bg-[#141414] border border-[#141414]">
                <StatCard label="Total Buses" value={buses.length.toString()} sub="Active in Network" />
                <StatCard label="On Time" value={buses.filter(b => b.status === 'On Time').length.toString()} sub="94.2% Reliability" />
                <StatCard label="Avg Load" value="72%" sub="Passenger Density" />
                <StatCard label="Alerts" value="2" sub="Requires Attention" color="text-red-600" />
              </div>

              {/* Data Table */}
              <div className="border border-[#141414]">
                <div className="grid grid-cols-5 p-4 border-b border-[#141414] bg-[#141414] text-[#E4E3E0] text-[10px] font-mono uppercase tracking-widest">
                  <div className="col-span-1">Bus ID</div>
                  <div className="col-span-1">Route</div>
                  <div className="col-span-1">Status</div>
                  <div className="col-span-1">Load</div>
                  <div className="col-span-1 text-right">Last Ping</div>
                </div>
                <div className="divide-y divide-[#141414]">
                  {filteredBuses.map((bus) => (
                    <div key={bus.id} className="grid grid-cols-5 p-4 hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors group cursor-pointer">
                      <div className="col-span-1 font-mono text-sm">{bus.id}</div>
                      <div className="col-span-1 font-serif italic text-sm">{bus.route}</div>
                      <div className="col-span-1 flex items-center gap-2">
                        <StatusBadge status={bus.status} />
                      </div>
                      <div className="col-span-1">
                        <div className="w-24 h-1.5 bg-gray-300 group-hover:bg-gray-700 rounded-full overflow-hidden">
                          <div 
                            className={cn(
                              "h-full transition-all duration-500",
                              bus.passengers > 40 ? "bg-red-500" : "bg-[#141414] group-hover:bg-[#E4E3E0]"
                            )}
                            style={{ width: `${(bus.passengers / 50) * 100}%` }}
                          />
                        </div>
                      </div>
                      <div className="col-span-1 text-right font-mono text-[10px] opacity-60 group-hover:opacity-100">
                        {new Date(bus.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'services' && (
            <motion.div 
              key="services"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-12"
            >
              <div className="max-w-3xl">
                <p className="text-xl font-serif leading-relaxed mb-6">
                  Managing 1,000+ microservices in a polyglot environment requires extreme observability. 
                  Our system leverages Rust for performance, Go for concurrency, and satirical Node.js for everything else.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Service List */}
                <div className="border border-[#141414] p-6 bg-white/50">
                  <h3 className="font-mono text-[10px] uppercase tracking-widest mb-6 flex items-center gap-2">
                    <Activity className="w-3 h-3" /> Critical Service Health
                  </h3>
                  <div className="space-y-4">
                    {services.map(svc => (
                      <div key={svc.id} className="flex items-center justify-between p-4 border border-[#141414] bg-[#E4E3E0]">
                        <div>
                          <p className="text-xs font-bold">{svc.name}</p>
                          <p className="text-[10px] font-mono opacity-50">{svc.id}</p>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="text-[10px] font-mono uppercase opacity-50">Latency</p>
                            <p className="text-xs font-mono">{svc.latency}</p>
                          </div>
                          <div className={cn(
                            "px-2 py-1 text-[9px] font-mono uppercase border",
                            svc.status === 'healthy' ? "bg-green-100 text-green-800 border-green-800" : "bg-orange-100 text-orange-800 border-orange-800"
                          )}>
                            {svc.status}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <button className="w-full mt-6 py-3 border border-[#141414] text-[10px] font-mono uppercase hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors flex items-center justify-center gap-2">
                    <RefreshCw className="w-3 h-3" /> View All 1,024 Services
                  </button>
                </div>

                {/* Event Stream */}
                <div className="border border-[#141414] p-6 bg-[#141414] text-[#E4E3E0] flex flex-col">
                  <h3 className="font-mono text-[10px] uppercase tracking-widest mb-6 flex items-center gap-2">
                    <Activity className="w-3 h-3" /> Kafka Event Backbone (Live)
                  </h3>
                  <div className="flex-1 space-y-2 font-mono text-[10px] overflow-hidden">
                    <AnimatePresence initial={false}>
                      {events.map((ev) => (
                        <motion.div 
                          key={ev.id}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0 }}
                          className="flex items-center gap-3 border-l border-white/20 pl-3 py-1"
                        >
                          <span className="opacity-40">[{ev.time}]</span>
                          <span className={cn(
                            ev.type === 'error' ? 'text-red-400' : 
                            ev.type === 'warning' ? 'text-orange-400' : 
                            ev.type === 'success' ? 'text-green-400' : 'text-blue-400'
                          )}>
                            {ev.msg}
                          </span>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                  <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-[8px] opacity-50">
                    <span>THROUGHPUT: 12.4k msg/s</span>
                    <span>TOPIC: omnibus.prod.events</span>
                  </div>
                </div>

                {/* Infrastructure Visualization */}
                <div className="border border-[#141414] p-6 bg-[#141414] text-[#E4E3E0] relative overflow-hidden lg:col-span-2">
                  <div className="relative z-10">
                    <h3 className="font-mono text-[10px] uppercase tracking-widest mb-6">Network Topology</h3>
                    <div className="aspect-square flex items-center justify-center">
                      <div className="relative w-48 h-48">
                        {/* Satirical "Mesh" Visualization */}
                        <div className="absolute inset-0 border border-white/20 rounded-full animate-[spin_10s_linear_infinite]" />
                        <div className="absolute inset-4 border border-white/10 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Server className="w-8 h-8" />
                        </div>
                        {Array.from({ length: 8 }).map((_, i) => (
                          <div 
                            key={i}
                            className="absolute w-2 h-2 bg-white rounded-full"
                            style={{
                              top: `${50 + 40 * Math.sin((i * 45 * Math.PI) / 180)}%`,
                              left: `${50 + 40 * Math.cos((i * 45 * Math.PI) / 180)}%`,
                            }}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="mt-8 grid grid-cols-2 gap-4 text-[10px] font-mono">
                      <div>
                        <p className="opacity-50 uppercase">Active Pods</p>
                        <p className="text-lg">4,209</p>
                      </div>
                      <div>
                        <p className="opacity-50 uppercase">Error Rate</p>
                        <p className="text-lg text-green-400">0.002%</p>
                      </div>
                    </div>
                  </div>
                  {/* Grid Background */}
                  <div className="absolute inset-0 opacity-10 pointer-events-none" 
                    style={{ backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)', backgroundSize: '20px 20px' }} 
                  />
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'analytics' && (
            <motion.div 
              key="analytics"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="border border-[#141414] p-8 bg-white">
                  <h3 className="font-serif italic text-xl mb-8">Passenger Volume (24h)</h3>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={PERFORMANCE_DATA}>
                        <defs>
                          <linearGradient id="colorPass" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#141414" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#141414" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                        <XAxis 
                          dataKey="time" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontFamily: 'monospace' }} 
                        />
                        <YAxis 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontFamily: 'monospace' }} 
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#141414', 
                            border: 'none', 
                            color: '#E4E3E0',
                            fontSize: '10px',
                            fontFamily: 'monospace'
                          }} 
                        />
                        <Area 
                          type="monotone" 
                          dataKey="passengers" 
                          stroke="#141414" 
                          fillOpacity={1} 
                          fill="url(#colorPass)" 
                          strokeWidth={2}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="border border-[#141414] p-8 bg-white">
                  <h3 className="font-serif italic text-xl mb-8">Network Efficiency</h3>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={PERFORMANCE_DATA}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                        <XAxis 
                          dataKey="time" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontFamily: 'monospace' }} 
                        />
                        <YAxis 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fontSize: 10, fontFamily: 'monospace' }} 
                        />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#141414', 
                            border: 'none', 
                            color: '#E4E3E0',
                            fontSize: '10px',
                            fontFamily: 'monospace'
                          }} 
                        />
                        <Line 
                          type="stepAfter" 
                          dataKey="efficiency" 
                          stroke="#141414" 
                          strokeWidth={2} 
                          dot={{ r: 4, fill: '#141414' }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="p-6 border border-[#141414] bg-[#141414] text-[#E4E3E0]">
                  <p className="text-[10px] font-mono uppercase opacity-50 mb-2">Fuel Economy</p>
                  <p className="text-3xl font-serif italic">8.4 km/L</p>
                  <div className="mt-4 flex items-center gap-2 text-green-400 text-[10px] font-mono">
                    <CheckCircle2 className="w-3 h-3" /> +12% vs Last Month
                  </div>
                </div>
                <div className="p-6 border border-[#141414] bg-white">
                  <p className="text-[10px] font-mono uppercase opacity-50 mb-2">Driver Satisfaction</p>
                  <p className="text-3xl font-serif italic">4.8/5.0</p>
                  <div className="mt-4 flex items-center gap-2 text-gray-400 text-[10px] font-mono">
                    <Users className="w-3 h-3" /> Based on 240 surveys
                  </div>
                </div>
                <div className="p-6 border border-[#141414] bg-white">
                  <p className="text-[10px] font-mono uppercase opacity-50 mb-2">Maintenance Backlog</p>
                  <p className="text-3xl font-serif italic">3 Units</p>
                  <div className="mt-4 flex items-center gap-2 text-orange-600 text-[10px] font-mono">
                    <AlertTriangle className="w-3 h-3" /> 1 Critical Priority
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* --- Footer / Status Bar --- */}
      <footer className="fixed bottom-0 left-0 right-0 h-8 bg-[#141414] text-[#E4E3E0] z-50 flex items-center justify-between px-4 text-[9px] font-mono uppercase tracking-widest">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <div className="w-1 h-1 rounded-full bg-green-500" />
            VPC: EST-01
          </span>
          <span>K8S: CLUSTER-ALPHA</span>
        </div>
        <div className="flex items-center gap-4">
          <span>DB: POSTGRES-PRIMARY</span>
          <span>CACHE: REDIS-01</span>
          <span className="opacity-50">© 2026 OMNIBUS SYSTEMS</span>
        </div>
      </footer>
    </div>
  );
}

// --- Subcomponents ---

function NavItem({ 
  icon, 
  label, 
  active = false, 
  onClick,
  badge
}: { 
  icon: React.ReactNode; 
  label: string; 
  active?: boolean; 
  onClick?: () => void;
  badge?: string;
}) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center justify-between px-4 py-2.5 text-xs transition-all group",
        active 
          ? "bg-[#141414] text-[#E4E3E0]" 
          : "hover:bg-[#141414]/5 text-[#141414]/70 hover:text-[#141414]"
      )}
    >
      <div className="flex items-center gap-3">
        <span className={cn("transition-transform group-hover:scale-110", active ? "text-[#E4E3E0]" : "text-[#141414]")}>
          {icon}
        </span>
        <span className="font-medium">{label}</span>
      </div>
      {badge && (
        <span className={cn(
          "text-[8px] px-1.5 py-0.5 rounded-sm font-mono",
          active ? "bg-[#E4E3E0] text-[#141414]" : "bg-[#141414] text-[#E4E3E0]"
        )}>
          {badge}
        </span>
      )}
      {!badge && active && <ChevronRight className="w-3 h-3" />}
    </button>
  );
}

function StatCard({ label, value, sub, color = "text-[#141414]" }: { label: string; value: string; sub: string; color?: string }) {
  return (
    <div className="bg-[#E4E3E0] p-6 flex flex-col justify-between h-32">
      <p className="text-[10px] font-mono uppercase tracking-widest opacity-50">{label}</p>
      <div>
        <p className={cn("text-4xl font-serif italic leading-none mb-1", color)}>{value}</p>
        <p className="text-[9px] font-mono uppercase opacity-40">{sub}</p>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: BusData['status'] }) {
  const styles = {
    'On Time': 'bg-green-100 text-green-800 border-green-800',
    'Delayed': 'bg-orange-100 text-orange-800 border-orange-800',
    'Maintenance': 'bg-red-100 text-red-800 border-red-800',
  };

  return (
    <span className={cn(
      "px-2 py-0.5 text-[9px] font-mono uppercase border",
      styles[status]
    )}>
      {status}
    </span>
  );
}
